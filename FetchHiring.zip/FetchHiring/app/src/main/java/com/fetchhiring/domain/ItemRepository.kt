package com.fetchhiring.domain

import android.content.Context
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import androidx.paging.PagingSource
import androidx.paging.PagingState
import androidx.room.Room
import com.fetchhiring.data.FHDatabase
import com.fetchhiring.data.RetrofitInstance
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

class ItemRepository @Inject constructor(private val itemDao: ItemDao) {

    fun getAllItems(): Flow<PagingData<ItemEntity>> {
        return Pager(
            config = PagingConfig(
                pageSize = 20,
                enablePlaceholders = false
            ),
            pagingSourceFactory = { itemDao.getItems() }
        ).flow
    }

    suspend fun refreshItems() {
        val items = RetrofitInstance.api.fetchItems().filter { !it.name.isNullOrEmpty() }
        itemDao.insertAll(items)
    }
}