package com.fetchhiring.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.fetchhiring.domain.ItemDao
import com.fetchhiring.domain.ItemEntity
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton


@Database(entities = [ItemEntity::class], version = 1, exportSchema = false)
abstract class FHDatabase : RoomDatabase() {
    abstract fun itemDao(): ItemDao
}
