package com.fetchhiring

import android.app.Application
import android.content.Context
import androidx.room.Room
import com.fetchhiring.data.ApiService
import com.fetchhiring.data.FHDatabase
import com.fetchhiring.data.RetrofitInstance
import com.fetchhiring.domain.ItemDao
import com.fetchhiring.domain.ItemRepository

import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.HiltAndroidApp
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@HiltAndroidApp
class FetchHiringApplication : Application()

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext appContext: Context): FHDatabase {
        return Room.databaseBuilder(
            appContext,
            FHDatabase::class.java,
            "item_database"
        ).build()
    }

    @Provides
    fun provideItemDao(db: FHDatabase): ItemDao = db.itemDao()

    @Provides
    fun provideApiService(): ApiService = RetrofitInstance.api

    @Provides
    fun provideRepository(itemDao: ItemDao): ItemRepository = ItemRepository(itemDao)
}