package com.fetchhiring.domain

import androidx.paging.PagingSource
import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query

@Entity(tableName = "items")
data class ItemEntity(
    @PrimaryKey val id: Int,
    val listId: Int,
    val name: String?
)

@Dao
interface ItemDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<ItemEntity>)

    @Query("SELECT * FROM items WHERE name IS NOT NULL AND name != '' ORDER BY listId, name")
    fun getItems(): PagingSource<Int, ItemEntity>
}
