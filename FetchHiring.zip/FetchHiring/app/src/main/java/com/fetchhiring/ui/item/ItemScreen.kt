package com.fetchhiring.ui.item

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CornerSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.paging.compose.LazyPagingItems
import androidx.paging.compose.collectAsLazyPagingItems
import com.fetchhiring.domain.ItemEntity
import kotlinx.coroutines.runBlocking

@Composable
fun ItemScreen(viewModel: ItemViewModel = hiltViewModel()) {
    val itemsList: LazyPagingItems<ItemEntity> = viewModel.items.collectAsLazyPagingItems()
    val listState = rememberLazyListState()
    val showScrollToTop by remember {
        derivedStateOf { listState.firstVisibleItemIndex > 0 }
    }

    LaunchedEffect(null) {
        viewModel.refreshItems()
    }
    Scaffold(
        floatingActionButton = {
            AnimatedVisibility(
                visible = showScrollToTop,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                FloatingActionButton(onClick = {
                    runBlocking {
                        listState.scrollToItem(0)
                    }
                }) {
                    Text("Top")
                }
            }
        }
    ) { paddingValues ->
        LazyColumn(
            state = listState,
            contentPadding = paddingValues,
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp)
        ) {

            item {
                Row(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "Id",
                        modifier = Modifier
                            .padding(vertical = 8.dp)
                            .fillMaxWidth(.33f)
                    )
                    Text(
                        text = "ListId",
                        modifier = Modifier
                            .padding(vertical = 8.dp)
                            .fillMaxWidth(.33f)
                    )
                    Text(
                        text = "Name",
                        modifier = Modifier
                            .padding(vertical = 8.dp)
                            .fillMaxWidth(.33f)
                    )

                }
            }
            for (i in 0 until itemsList.itemCount) {
                itemsList[i]?.let {
                    item(key = it.id) {
                        Row(
                            modifier = Modifier
                                .padding(4.dp)
                                .background(
                                    shape = RoundedCornerShape(corner = CornerSize(4.dp)),
                                    color = MaterialTheme.colorScheme.surface
                                )
                                .fillMaxWidth()
                        ) {
                            Text(
                                text = "${it.listId}",
                                modifier = Modifier
                                    .padding(vertical = 8.dp)
                                    .fillMaxWidth(.33f),
                                style = TextStyle(color = MaterialTheme.colorScheme.onSurface)
                            )
                            Text(
                                text = "${it.listId}",
                                modifier = Modifier
                                    .padding(vertical = 8.dp)
                                    .fillMaxWidth(.33f),
                                style = TextStyle(color = MaterialTheme.colorScheme.onSurface)
                            )
                            Text(
                                text = "${it.name}",
                                modifier = Modifier
                                    .padding(vertical = 8.dp)
                                    .fillMaxWidth(.33f),
                                style = TextStyle(color = MaterialTheme.colorScheme.onSurface)
                            )

                        }
                    }
                }
            }
        }
    }
}