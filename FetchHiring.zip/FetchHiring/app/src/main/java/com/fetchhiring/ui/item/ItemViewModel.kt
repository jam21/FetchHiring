package com.fetchhiring.ui.item

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.paging.PagingData
import androidx.paging.cachedIn
import com.fetchhiring.domain.ItemEntity
import com.fetchhiring.domain.ItemRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ItemViewModel @Inject constructor(private val repository: ItemRepository) : ViewModel() {

    val items: Flow<PagingData<ItemEntity>> = repository.getAllItems().cachedIn(viewModelScope)

    fun refreshItems() {
        viewModelScope.launch {
            repository.refreshItems()
        }
    }
}